# llm_evaluator

`llm_evaluator` is a Python package that provides tools for evaluating language models during training.

## Installation

```bash
pip install llm_evaluator
